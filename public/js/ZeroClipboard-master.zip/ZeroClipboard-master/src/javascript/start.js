/*!
 * {{name}}
 * {{description}}
 * Copyright 2012 {{#each contributors}}{{name}}, {{/each}}.
 * Released under the {{license}} license
 * {{homepage}}
 * v{{version}}
 */
(function () {
  "use strict";